public class Record {
    private String recordId;
    private String customerId;
    private String loanType;
    private double interestRate;
    private double amountLeft;
    private int loanTermLeft;

    // Default constructor
    public Record() {
    }

    // Constructor with custom property values
    public Record(String recordId, String customerId, String loanType, double interestRate, double amountLeft, int loanTermLeft) {
        this.recordId = recordId;
        this.customerId = customerId;
        this.loanType = loanType;
        this.interestRate = interestRate;
        this.amountLeft = amountLeft;
        this.loanTermLeft = loanTermLeft;
    }

    // Getter and setter methods for all properties
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getAmountLeft() {
        return amountLeft;
    }

    public void setAmountLeft(double amountLeft) {
        this.amountLeft = amountLeft;
    }

    public int getLoanTermLeft() {
        return loanTermLeft;
    }

    public void setLoanTermLeft(int loanTermLeft) {
        this.loanTermLeft = loanTermLeft;
    }
}