import java.util.Scanner;

public class XYZBank {
    // Define ANSI color codes
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";

    public static void main(String[] args) {
        // Initialize scanner to read user input
        Scanner scanner = new Scanner(System.in);

    // Prompt user to enter the maximum number of records
    int maxRecords;
    while (true) {
        System.out.print("Enter the maximum number of records: ");
        String input = scanner.nextLine();
        try {
            maxRecords = Integer.parseInt(input);
            break; // Exit the loop if the input is a valid number
        } catch (NumberFormatException e) {
            System.out.println(ANSI_RED + "Invalid input. Please enter a valid number." + ANSI_RESET);
        }
    }


        // Create an array to store records based on the maximum number of records
        Record[] records = new Record[maxRecords];
        
        // Variable to keep track of the number of records entered
        int recordCount = 0;

        // Loop to input records
        while (recordCount < maxRecords) {
            // Prompt user to enter details for the current record
            System.out.println("\nEnter details for Record " + (recordCount + 1) + ":");

            while (true) {
                // Prompt user to enter record ID
                System.out.print("Enter Record ID (XXXXXX): ");
                String recordId = scanner.nextLine();
            
                // Validate the format of the record ID
                if (!isValidRecordId(recordId)) {
                    System.out.println(ANSI_RED + "Invalid Record ID format. Record ID should be 6 digits." + ANSI_RESET);
                    continue;
                }
            
                // Prompt user to enter customer ID
                String customerId;
                boolean tryAgain = false;
                do {
                    System.out.print("Enter Customer ID (AAAXXX): ");
                    customerId = scanner.nextLine();
            
                    // Validate the format of the customer ID
                    if (!isValidCustomerId(customerId)) {
                        System.out.println(ANSI_RED + "Invalid Customer ID format. Customer ID should be 3 letters followed by 3 numbers." + ANSI_RESET);
                        tryAgain = true;
                    } else {
                        tryAgain = false;
                    }
                } while (tryAgain);
            
                // Check if customer ID is in uppercase
                if (!customerId.equals(customerId.toUpperCase())) {
                    System.out.println(ANSI_RED + "Customer ID should be entered in uppercase." + ANSI_RESET);
                    continue;
                }

                // Check for duplicate records
                boolean duplicate = false;
                for (int i = 0; i < recordCount; i++) {
                    if (records[i].getRecordId().equals(recordId) && records[i].getCustomerId().equals(customerId)) {
                        duplicate = true;
                        break;
                    }
                }
                // If duplicate record found, prompt user and continue to next iteration
                if (duplicate) {
                    System.out.println(ANSI_RED + "Record with the same Record ID and Customer ID already exists." + ANSI_RESET);
                    continue;
                }

                // Prompt user to enter loan type
                String loanType;
                while (true) {
                    System.out.print("Enter Loan Type (Auto, Builder, Mortgage, Personal, Other): ");
                    loanType = scanner.nextLine();
                    if (loanType.isEmpty()) {
                        System.out.println(ANSI_RED + "Error: Loan Type cannot be empty. Please specify a valid type." + ANSI_RESET);
                    } else if (!isValidLoanType(loanType)) {
                        System.out.println(ANSI_RED + "Invalid Loan Type. Allowed loan types are: Auto, Builder, Mortgage, Personal, Other." + ANSI_RESET);
                    } else {
                        break; // Break the loop if a valid loan type is provided
                    }
                }

                // Validate the loan type
                if (!isValidLoanType(loanType)) {
                    System.out.println(ANSI_RED + "Invalid Loan Type. Allowed loan types are: Auto, Builder, Mortgage, Personal, Other." + ANSI_RESET);
                    continue;
                }

                // Prompt user to enter interest rate
                double interestRate;
                while (true) {
                    System.out.print("Enter Interest Rate: ");
                    String interestRateInput = scanner.nextLine();
                    if (interestRateInput.isEmpty()) {
                        System.out.println(ANSI_RED + "Error: Interest Rate cannot be empty. Please enter a valid number." + ANSI_RESET);
                    } else {
                        try {
                            interestRate = Double.parseDouble(interestRateInput);
                            break; // Break the loop if a valid interest rate is provided
                        } catch (NumberFormatException e) {
                            System.out.println(ANSI_RED + "Invalid input for Interest Rate. Please enter a valid number." + ANSI_RESET);
                        }
                    }
                }

                // Prompt user to enter amount left to pay
                double amountLeft;
                while (true) {
                    System.out.print("Enter Amount Left to Pay (in thousands pounds): ");
                    String amountLeftInput = scanner.nextLine();
                    if (amountLeftInput.isEmpty()) {
                        System.out.println(ANSI_RED + "Error: Amount Left to Pay cannot be empty. Please enter a valid amount." + ANSI_RESET);
                    } else {
                        try {
                            amountLeft = Double.parseDouble(amountLeftInput);
                            break; // Break the loop if a valid amount left to pay is provided
                        } catch (NumberFormatException e) {
                            System.out.println(ANSI_RED + "Invalid input for Amount Left to Pay. Please enter a valid number." + ANSI_RESET);
                        }
                    }
                }


                // Prompt user to enter loan term left
                int loanTermLeft;
                while (true) {
                    System.out.print("Enter Loan Term Left (in years): ");
                    String loanTermLeftInput = scanner.nextLine();
                    if (loanTermLeftInput.isEmpty()) {
                        System.out.println(ANSI_RED + "Error: Loan Term Left cannot be empty. Please enter a valid integer." + ANSI_RESET);
                    } else if (!loanTermLeftInput.matches("\\d+")) {
                        System.out.println(ANSI_RED + "Invalid input for Loan Term Left. Please enter a valid integer." + ANSI_RESET);
                    } else {
                        loanTermLeft = Integer.parseInt(loanTermLeftInput);
                        break; // Break the loop if a valid loan term left is provided
                    }
                }



                // Create a new record object and add it to the records array
                records[recordCount] = new Record(recordId, customerId, loanType, interestRate, amountLeft, loanTermLeft);
                // Increment the record count
                recordCount++;

                // Break out of the inner loop to move to the next record
                break;
            }

            // Ask if the user wants to add another record
            String addAnother;
            do {
                System.out.print("\nDo you want to add another record? (yes/no): ");
                addAnother = scanner.nextLine();
                if (!addAnother.equalsIgnoreCase("yes") && !addAnother.equalsIgnoreCase("no")) {
                    System.out.println(ANSI_RED + "Error: Invalid input. Please enter 'yes' or 'no'." + ANSI_RESET);
                }
            } while (!addAnother.equalsIgnoreCase("yes") && !addAnother.equalsIgnoreCase("no"));

            if (addAnother.equalsIgnoreCase("no")) {
                break; // Exit the loop if the user chooses not to add another record
            }
            
        }

        // Output header for the Maximum number of records
        System.out.print("\nMaximum number of Records: " + maxRecords);

        // Output header for the registered records
        System.out.println("\nRecords Registered:");
        // Add an empty line
        System.out.println();
        System.out.printf("%-12s %-12s %-12s %-12s %-12s %-10s%n", "RecordID", "CustomerID", "LoanType", "IntRate", "AmountLeft", "TimeLeft");

        // Output records
        for (int i = 0; i < recordCount; i++) {
            Record record = records[i];
            System.out.printf("%-12s %-12s %-12s %-12.2f %-12.0f %-12d%n",
                    record.getRecordId(), record.getCustomerId(), record.getLoanType(),
                    record.getInterestRate(), record.getAmountLeft(), record.getLoanTermLeft());
        }


    // Menu for adding, printing records again, or quitting
    while (true) {
        System.out.println("\nChoose an option:");
        System.out.println("1. Add another record");
        System.out.println("2. Print records again");
        System.out.println("3. Quit");

        // Prompt user for choice
        System.out.print("Enter your choice: ");
        int choice;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println(ANSI_RED + "Invalid choice. Please enter a number between 1 and 3." + ANSI_RESET);
            continue;
        }

    switch (choice) {
        case 1:
            // Add another record
            if (recordCount < maxRecords) {
                // Prompt user to enter details for the new record
                System.out.println("\nEnter details for the new record:");
                // Similar logic to inputting records in the main loop

                String recordId;
                String customerId;
                String loanType;
                double interestRate;
                double amountLeft;
                int loanTermLeft;

                // Loop to validate and input details for the new record
                while (true) {
                    // Prompt user to enter record ID
                    System.out.print("Enter Record ID (XXXXXX): ");
                    recordId = scanner.nextLine();

                    // Validate the format of the record ID
                    if (!isValidRecordId(recordId)) {
                        System.out.println(ANSI_RED + "Invalid Record ID format. Record ID should be 6 digits." + ANSI_RESET);
                        continue;
                    }

                    // Prompt user to enter customer ID
                    while (true) {
                        System.out.print("Enter Customer ID (AAAXXX): ");
                        customerId = scanner.nextLine();

                        // Validate the format of the customer ID
                        if (!isValidCustomerId(customerId)) {
                            System.out.println(ANSI_RED + "Invalid Customer ID format. Customer ID should be 3 letters followed by 3 numbers." + ANSI_RESET);
                            continue;
                        }
                        break;
                    }

                    // Check if customer ID is in uppercase
                    if (!customerId.equals(customerId.toUpperCase())) {
                        System.out.println(ANSI_RED + "Customer ID should be entered in uppercase." + ANSI_RESET);
                        continue;
                    }

                    // Check for duplicate records
                    boolean duplicate = false;
                    for (int i = 0; i < recordCount; i++) {
                        if (records[i].getRecordId().equals(recordId) && records[i].getCustomerId().equals(customerId)) {
                            duplicate = true;
                            break;
                        }
                    }
                    // If duplicate record found, prompt user and continue to next iteration
                    if (duplicate) {
                        System.out.println(ANSI_RED + "Record with the same Record ID and Customer ID already exists." + ANSI_RESET);
                        continue;
                    }

                    // Prompt user to enter loan type
                    System.out.print("Enter Loan Type (Auto, Builder, Mortgage, Personal, Other): ");
                    loanType = scanner.nextLine();

                    // Validate the loan type
                    if (!isValidLoanType(loanType)) {
                        System.out.println(ANSI_RED + "Invalid Loan Type. Allowed loan types are: Auto, Builder, Mortgage, Personal, Other." + ANSI_RESET);
                        continue;
                    }

                    // Prompt user to enter interest rate
                    while (true) {
                        System.out.print("Enter Interest Rate: ");
                        String interestRateInput = scanner.nextLine();
                        try {
                            interestRate = Double.parseDouble(interestRateInput);
                            break;
                        } catch (NumberFormatException e) {
                            System.out.println(ANSI_RED + "Invalid input for Interest Rate. Please enter a valid number." + ANSI_RESET);
                        }
                    }

                    // Prompt user to enter amount left to pay
                    while (true) {
                        System.out.print("Enter Amount Left to Pay (in thousands pounds): ");
                        String amountLeftInput = scanner.nextLine();
                        try {
                            amountLeft = Double.parseDouble(amountLeftInput);
                            break;
                        } catch (NumberFormatException e) {
                            System.out.println(ANSI_RED + "Invalid input for Amount Left to Pay. Please enter a valid number." + ANSI_RESET);
                        }
                    }

                    // Prompt user to enter loan term left
                    while (true) {
                        System.out.print("Enter Loan Term Left (in years): ");
                        String loanTermLeftInput = scanner.nextLine();
                        try {
                            loanTermLeft = Integer.parseInt(loanTermLeftInput);
                            break;
                        } catch (NumberFormatException e) {
                            System.out.println(ANSI_RED + "Invalid input for Loan Term Left. Please enter a valid integer." + ANSI_RESET);
                        }
                    }

                    // Create a new record object and add it to the records array
                    records[recordCount] = new Record(recordId, customerId, loanType, interestRate, amountLeft, loanTermLeft);
                    // Increment the record count
                    recordCount++;
                    break;
                }
            } else {
                System.out.println(ANSI_RED + "Maximum number of records reached. Cannot add more records." + ANSI_RESET);
            }
            break;

        case 2:
            // Print records again
            // Output header for the registered records
            System.out.print("\nMaximum number of Records: " + maxRecords);
            System.out.println("\nRecords Registered:");
            System.out.println();
            System.out.printf("%-12s %-12s %-12s %-12s %-12s %-12s%n", "RecordID", "CustomerID", "LoanType", "IntRate", "AmountLeft", "TimeLeft");

            // Output records
            for (int i = 0; i < recordCount; i++) {
                Record record = records[i];
                System.out.printf("%-12s %-12s %-12s %-12.2f %-12.2f %-12d%n",
                        record.getRecordId(), record.getCustomerId(), record.getLoanType(),
                        record.getInterestRate(), record.getAmountLeft(), record.getLoanTermLeft());
            }
            break;

        case 3:
            // Quit
            System.out.println("Quitting program...");
            // Close the scanner since input is complete
            scanner.close();
            return;

        default:
            System.out.println(ANSI_RED + "Invalid choice. Please enter a number between 1 and 3." + ANSI_RESET);
        }
    }

}


    // Method to validate record ID format
    private static boolean isValidRecordId(String recordId) {
        return recordId.matches("\\d{6}");
    }

    // Method to validate customer ID format
    private static boolean isValidCustomerId(String customerId) {
        return customerId.matches("[A-Z]{3}\\d{3}");
    }

    // Method to validate loan type
    private static boolean isValidLoanType(String loanType) {
        String[] allowedLoanTypes = {"Auto", "Builder", "Mortgage", "Personal", "Other"};
        for (String allowedType : allowedLoanTypes) {
            if (allowedType.equalsIgnoreCase(loanType)) {
                return true;
            }
        }
        return false;
    }
}
